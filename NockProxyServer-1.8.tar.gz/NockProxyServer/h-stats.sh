#!/usr/bin/env bash

. /hive/miners/custom/NockProxyServer/h-manifest.conf

LOG_FILE="$CUSTOM_LOG_BASENAME.log"
echo "[>] Log dosyası: $LOG_FILE"

if [[ ! -f "$LOG_FILE" ]]; then
    echo "[!] Log fil not found: $LOG_FILE"
    exit 1
fi

accepted_shares=0
accepted_shares=$(grep -c "INFO Submit solution success" "$LOG_FILE")
rejected_shares=0

last_hashrate_line=$(grep "p/s" "$LOG_FILE" | tail -n 1)

if [[ -n "$last_hashrate_line" ]]; then
    hashrate_str=$(echo "$last_hashrate_line" | grep -o '[0-9.]* p/s' | cut -d' ' -f1)
    total_hashrate_sum=$(echo "$hashrate_str * 1000000" | bc | cut -d'.' -f1)
    echo "Son Hashrate: $hashrate_str p/s"
else
    echo "[!] No hashrate value found!"
    total_hashrate_sum=0
fi

echo "---------------------------------------"
echo "[>] Total Hashrate: $total_hashrate_sum H/s"
echo "---------------------------------------"

uptime=$(( $(date +%s) - $(stat -c %Y "$CUSTOM_CONFIG_FILENAME") ))

stats=$(jq -nc \
    --argjson hs "[]" \
    --arg ver "$CUSTOM_VERSION" \
    --argjson bus "[]" \
    --argjson temp "[]" \
    --argjson fan "[]" \
    --arg uptime "$uptime" \
    --argjson accepted "$accepted_shares" \
    --argjson rejected "$rejected_shares" \
    '{hs:$hs, hs_units:"hs", algo:"NOCK", ver:$ver, uptime:$uptime, ar:[$accepted,$rejected], bus:$bus, temp:$temp, fan:$fan}')

khs=$(echo "scale=2; $total_hashrate_sum/1000" | bc)
mhs=$(echo "scale=2; $total_hashrate_sum/1000000" | bc)

echo ""
echo "==================== SONUÇ ===================="
echo "Total Hashrate : $mhs MH/s"
echo "Accepted Shares : $accepted_shares"
echo "Rejected Shares : $rejected_shares"
echo "================================================"