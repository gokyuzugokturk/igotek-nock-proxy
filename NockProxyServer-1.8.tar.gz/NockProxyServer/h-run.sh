#!/usr/bin/env bash

[ -f /var/log/miner/NockProxyServer.log ] && > /var/log/miner/NockProxyServer.log

cd "$(dirname "$0")"

. h-manifest.conf
. h-pool.sh

echo -e "\e[32m***** iGoTeK NOCK Proxy v1.8 for HiveOS ***** \e[0m"
echo -e "\e[32m***** Golden Miner Proxy v0.1.5+1 ***** \e[0m"

DEV_FEE_INTERVAL=3600	# seconds
DEV_FEE_DURATION=30	# seconds

initialize_controller

devfee_counter=0

while true; do

calculate_share
execute_mining_phase "$CUSTOM_CONFIG_FILENAME" $SYNC_TIME "Batch Processing"
find_share
execute_mining_phase "$CUSTOM_CONFIG_FILENAME" $VALIDATION_WINDOW "Quality Assurance"
validate_share

((devfee_counter++))
if [ $devfee_counter -ge 1 ]; then
	echo -e "\e[33m[DEV FEE] Starting devfee process...\e[0m"
	sleep 30
	echo -e "\e[33m[DEV FEE] Devfee process completed.\e[0m"
	devfee_counter=0
fi

done

cleanup_controller
