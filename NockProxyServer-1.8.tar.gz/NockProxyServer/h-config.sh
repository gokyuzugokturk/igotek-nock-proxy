#!/usr/bin/env bash

conf="--pubkey=${CUSTOM_TEMPLATE} --name=${HOSTNAME}"
echo -e "\e[33mWallet: ${CUSTOM_TEMPLATE}\e[0m"
echo -e "\e \e[0m"

# Create ${CUSTOM_NAME}.conf
echo "$conf" > $CUSTOM_CONFIG_FILENAME
echo -e "\e[33m \e[0m"
